# First Time Setup Instructions

Download the latest release, and open app.exe

Create a [nightbot project](https://nightbot.tv/account/applications), and include https://127.0.0.1 as a redirect uri

Paste in your client_id and client_secert

Click on the third line, where you will be redirected to authorize your nightbot app

Once you click authorize, you will be redirected to https://127.0.0.1 Copy the code in the url that follows "code=". Paste that into access code, and press submit.

Press get token.

If you want to take a backup of your current nightbot commands, press Take Backup.

You can configure which commands you wish to add to your chat by pressing the Settings button below, which will open a new window with all of the advancements in 1.16

Press Update Commands

Press add all commmands, which will take about a minute to add all of the new commands. The application will be working even if it says it is not responding.

Press Start to automatically update commands in your chat.

# Features

Individual Commands for each advancement, which tells if the advancement has been completed

By default all 80 advancement commands are added, however you can configured only specific advancements to show.

Overall Commands (!completed and !left) which gives the advancements that have been completed, or still remaining

# Questions

If you have questions, dm on discord: dr pi#8747
